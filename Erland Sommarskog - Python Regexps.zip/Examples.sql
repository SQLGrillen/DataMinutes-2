-- Make sure that external scripts are enabled.
EXEC sp_configure 'external scripts enabled', 1
RECONFIGURE
go
USE tempdb
go
-- Set up table for first example.
DROP TABLE IF EXISTS Playdata
CREATE TABLE Playdata (id   int            NOT NULL,
                       txt  nvarchar(200)  NULL,
     CONSTRAINT pk_Playdata PRIMARY KEY (id)
)
INSERT Playdata(id, txt)
   VALUES (1, N'1,2,3,4'),
          (2, N'Adam, Betty,  Charlie'),
          (3, N'XV, LXI,VII,MCM'),
          (4, N'This, is, perfect'),
          (5, N'No comma in this text'),
          (6, N'ABC,,DDD,, F,, XYZ')
go
-- Set up Python script for replacements.
DECLARE @python_script nvarchar(MAX) = N'
import re, pandas                          # Import package for regexps and pandas.
Data["txt"] = pandas.Series([              # Python/Pandas mumbo-jumbo. :-)
      re.sub(r",\s*(\w)", r", \1", str)    # This is where substituion happens.
      for str in Data["txt"]])
'

-- Run script to get data back. 
EXEC sp_execute_external_script @language = N'Python', -- Set language.
     @input_data_1 = N'SELECT id, txt FROM Playdata',  -- Data sent to Python.
     @input_data_1_name = N'Data',           -- Name of Python variable for input.
     @output_data_1_name = N'Data',          -- Name of Python variable for output.
     @script = @python_script

-- If we want to update the base table, we can capture the result in a 
-- temp table with INSERT-EXEC.
DROP TABLE IF EXISTS #result
CREATE TABLE #result(id     int           NOT NULL PRIMARY KEY,
                     txt    nvarchar(200) NULL)

-- Run with INSERT-EXEC.
INSERT #result (id, txt)
   EXEC sp_execute_external_script @language = N'Python', 
        @input_data_1 = N'SELECT id, txt FROM Playdata', 
        @input_data_1_name = N'Data',
        @output_data_1_name = N'Data',
        @script = @python_script

-- Update source table.
UPDATE Playdata
SET    txt = r.txt
FROM   Playdata P
JOIN   #result r ON P.id = r.id

-- Display result.
SELECT id, txt FROM Playdata
go
-------------------------------------------------------------
-- Second example: remove titles.
DROP TABLE IF EXISTS Titles, Names

-- First, a table with titles to remove.
CREATE TABLE Titles (title nvarchar(50) NOT NULL 
           CONSTRAINT pk_Titles PRIMARY KEY(title)
)
INSERT INTO Titles (title)
VALUES ('inc'), ('ltd'), ('Mr'), ('Dr'), ('Sr')

-- The names to clean up.
CREATE TABLE Names (id       int           NOT NULL, 
                    fullname nvarchar(100) NOT NULL,
                    CONSTRAINT pk_Names PRIMARY KEY (id)
)
INSERT INTO Names (id, fullname) 
   VALUES (1, 'Big Business Inc.'),
          (2, 'Mary Jones Sr.'),
          (3, 'English Drinks Ltd'),
          (4, 'Frank Hinc'),
          (5, 'Dr. Michael Keen'),
          (6, 'Mr. John King Sr.')

-- Form a regexp pattern from the Titles table.
DECLARE @RegExp nvarchar(MAX)
SELECT @RegExp = string_agg('(\s*\b' + title + '\b\.*\s*)', '|')
FROM   Titles

-- Look at the RegExp created.
SELECT @RegExp

-- The Python script.
DECLARE @python_script nvarchar(MAX) = N'
import re, pandas
Data["cleanname"] = pandas.Series([
    re.sub(RegExp, r"", str, flags=re.IGNORECASE) 
    for str in Data["fullname"]])
'
-- Run it.
EXEC sp_execute_external_script @language = N'Python', 
     @input_data_1 = N'SELECT id, fullname FROM Names', 
     @input_data_1_name = N'Data',
     @output_data_1_name = N'Data',
     @script = @python_script,
     @params = N'@RegExp nvarchar(MAX)',  -- Parameter list, must come here!
     @RegExp = @RegExp                   -- The actual parameter to pass.
go

-------------------------------------------------------------
-- Bonus example. We have parameter names enclosed by braces
-- and we have the actual parameter values in a table. We want to 
-- replace parameter holders with the values.
DROP TABLE IF EXISTS DataTable
CREATE TABLE DataTable (
     id int,
     notes varchar(1000)
 );
INSERT INTO DataTable VALUES 
   (1, 'develop document disseminate to {ac-1_prm_1} and {one_more_par} for the benefit of Mr Kite'),
   (2, 'develop document to {ac-1_prm_2}'),
   (3, 'The Organization {no_such_param} is winning the stakes');

DECLARE @DataTableParameter TABLE (
     parameterid varchar(100),
     [value] varchar(100),
     id int
);
INSERT INTO @DataTableParameter VALUES
    ('ac-1_prm_1', 'apple doc.', 1),
    ('ac-1_prm_2', 'google doc.', 1),
    ('ac-1_prm_3', 'facebook doc.', 2),
    ('one_more_par', 'other sources', 3)

-- To do this, we need a Python dictionary. We create the Python code to 
-- populate that dictionary here.
DECLARE @createdict nvarchar(MAX)
SELECT @createdict  = 'params = {' + 
            string_agg(quotename(parameterid, '''') + ':' + 
                       quotename(value, ''''), ', ') + '}'
FROM   @DataTableParameter

-- Inspect it.
SELECT @createdict

-- Here is the Python script.
DECLARE @pyscript nvarchar(MAX) = N'
import re, pandas           # Import re and pandas.

# This subroutine is called from re.sub.
def paramrepl(matchobj):
    param = matchobj.group(1)             # Get the parameter name.
    if param in params:                   # Is key defined?
       return params[matchobj.group(1)]   # Yes, return value.
    else:
       return "{" + param + "}"           # No, return parameter unreplaced.

' + @createdict + '                       # Here comes that dictionary created in T-SQL.

Data["notes"] = pandas.Series(
       [re.sub(r"\{([^\}]+)\}",           # Pattern for things included in braces.
               paramrepl,                 # This is the def defined above!
               str)                
       for str in Data["notes"]])
'

-- Run it.
EXEC sp_execute_external_script 
      @language           = N'Python',
      @input_data_1       = N'SELECT id, notes FROM DataTable',
      @input_data_1_name  = N'Data',
      @output_data_1_name = N'Data',
      @script             = @pyscript
-- You can add WITH RESULT SETS to name the output columns.
WITH RESULT SETS ((id int,
                   notes varchar(1000)))
go
--------------------------------------------------------
-- Final example. This demonstrates how to search for matches, 
-- using re.search. That is, we want to find rows that match a
-- certain regexp pattern. In this example, we want to find
-- rows which has a word with both letters and numbers in it.

DROP TABLE IF EXISTS FinalExample
CREATE TABLE FinalExample (id   int            NOT NULL,
                           txt  nvarchar(200)  NULL,
     CONSTRAINT pk_FinalExample PRIMARY KEY (id)
)
INSERT FinalExample(id, txt)
   VALUES (1, N'This is a text with a number 70491SPLICED in.'),
          (2, N'This text has 8908 only clean numbers in it 988.'),
          (3, N'It is on7777ly getting worse.'),
          (4, N'951357'),
          (5, N'There are no numbers at all in this text.'),
          (6, N'This is number14.')
go
-- Here is the Python script. The pattern is different, but you only need
-- think about the first argument to re.search, so that you have the regexp
-- you problem requires. The rest will be the same every time.
DECLARE @pyscript nvarchar (MAX) = N'
import re, pandas
condition = Input["txt"].map(lambda str: 
     re.search(r"([a-z]\d)|(\d[a-z])(?i)", str, ) != None) # (?i) an alternate way to express case-insensitive.
Ret = Input[condition]
'   

EXEC sp_execute_external_script @language = N'Python', 
     @input_data_1 = N'SELECT id, txt FROM FinalExample', 
     @input_data_1_name = N'Input', -- This time, we have different names
     @output_data_1_name = N'Ret',  -- for input and output.
     @script = @pyscript
WITH RESULT SETS ((id     int,
                   txt    nvarchar(200)))
go