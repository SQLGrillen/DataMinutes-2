USE [master];
DROP DATABASE IF EXISTS DataMinutes;
GO
CREATE DATABASE [DataMinutes];
GO
USE [DataMinutes];
CREATE TABLE Establishments
([LocId]        INT IDENTITY(1, 1),
 [FunctionUsed] NVARCHAR(50) NOT NULL,
 [Name]         NVARCHAR(100) NOT NULL,
 CONSTRAINT PK_Establishments PRIMARY KEY CLUSTERED(LocId)
);

select * from DataMinutes.dbo.Establishments