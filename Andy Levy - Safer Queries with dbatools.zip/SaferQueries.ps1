Clear-Host;
$ErrorActionPreference = "Continue";
$VerbosePreference = "SilentlyContinue";

Import-Module dbatools;
$SQLInstance = "YOURSERVER";
$DemoDatabase = "DataMinutes";
$ErrorActionPreference = "Continue";
$VerbosePreference = "Continue";

function Invoke-Safely {
    Clear-Host;
    Write-Verbose $MyInvocation.MyCommand; 
    $Establishments = @(
        "Simply Crepes",
        "Rocky');create table [reallyPwned] ([Gotcha] int identity(1,1));--s Cafe");

    $MyParameterizedQuery = "insert into [dbo].[Establishments]([FunctionUsed],[Name])
    values (@FunctionName,@EstablishmentName)";
    foreach ($Establishment in $Establishments) {
        $QueryParameters = @{
            "FunctionName"      = "Invoke-DbaQuery";
            "EstablishmentName" = $Establishment;
        }
        Invoke-DbaQuery -SqlInstance $SQLInstance -Database $DemoDatabase -Query $MyParameterizedQuery -SqlParameters $QueryParameters;
    }
}
Invoke-Safely;
Invoke-DbaQuery -SqlInstance $SqlInstance -Database $DemoDatabase -Query "select * from [dbo].[Establishments]"

Invoke-DbaQuery -SqlInstance $SqlInstance -Database $DemoDatabase -Query "select name,create_date from sys.tables" | select-object name, create_date;

function Get-Safely {
    Clear-Host;
    Write-Verbose $MyInvocation.MyCommand; 
    $Establishments = @(
        "Simply Crepes",
        "Rocky' and 0=0 UNION ALL select NULL,NULL,[Name] from sys.tables;create table [pwnedYetAgain] ([Gotcha] int identity(1,1));--s Cafe");
    $MyParameterizedQuery = "Select LocId,FunctionUsed, [Name] from [dbo].[Establishments] where [Name] = @EstablishmentName;"
    foreach ($Establishment in $Establishments) {
        $QueryParameters = @{
            "EstablishmentName" = $Establishment;
        }
        Invoke-DbaQuery -SqlInstance $SQLInstance -Database $DemoDatabase -Query $MyParameterizedQuery -SqlParameters $QueryParameters;
    }
}
Get-Safely;

Invoke-DbaQuery -SqlInstance $SqlInstance -Database $DemoDatabase -Query "select name,create_date from sys.tables" | select-object name, create_date;

<#
For more about SQL Injection, check out Bert Wagner's blog posts and GroupBy session:

https://bertwagner.com/category/sql-injection/
https://groupby.org/conference-session-abstracts/sql-injection-attacks-is-your-data-secure/

Andy Levy
@alevyinroc
https://flxsql.com/
#>

