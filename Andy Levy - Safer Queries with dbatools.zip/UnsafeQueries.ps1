Clear-Host;
$ErrorActionPreference = "Continue";
$VerbosePreference = "SilentlyContinue";

Import-Module sqlserver;
$SQLInstance = "YOURSERVER";
$DemoDatabase = "DataMinutes";
$ErrorActionPreference = "Continue";
$VerbosePreference = "Continue";

function Invoke-Naive {
    Clear-Host;
    Write-Verbose $MyInvocation.MyCommand; 
    $Establishments = @(
        "Simply Crepes",
        "Rocky's Cafe");

    foreach ($Establishment in $Establishments) {
        $MyInsertQuery = "insert into dbo.[Establishments]([FunctionUsed],[Name]) 
                    values ('Invoke-SqlCmd','$Establishment');";
        Write-Verbose $MyInsertQuery;
        Invoke-SqlCmd -ServerInstance $SQLInstance -Query $MyInsertQuery -Database $DemoDatabase;
    }
}
Invoke-Naive;

Invoke-SqlCmd -ServerInstance $SqlInstance -Database $DemoDatabase -Query "select * from [dbo].[Establishments]"

function Invoke-WithInjection {
    Clear-Host;
    Write-Verbose $MyInvocation.MyCommand; 
    $Establishments = @(
        "Simply Crepes",
        "Rocky');create table [pwned] ([Gotcha] int identity(1,1));--s Cafe");

    foreach ($Establishment in $Establishments) {
        $MyInsertQuery = "insert into [dbo].[Establishments]([FunctionUsed],[Name])
        values ('Invoke-SqlCmd','$Establishment');";
        Write-Verbose $MyInsertQuery;
        invoke-sqlcmd -server $SQLInstance -query $MyInsertQuery -Database $DemoDatabase;
    }
}
Invoke-WithInjection;

Invoke-SqlCmd -ServerInstance $SqlInstance -Database $DemoDatabase -Query "select * from [dbo].[Establishments]"

Invoke-SqlCmd -ServerInstance $SqlInstance -Database $DemoDatabase -Query "select name,create_date from sys.tables" | select-object name, create_date;

function Get-Unsafe {
    Clear-Host;
    Write-Verbose $MyInvocation.MyCommand; 
    $Establishments = @(
        "Simply Crepes",
        "Rocky' and 0=0 UNION ALL select NULL,NULL,[Name] from sys.tables;create table [pwnedAgain] ([Gotcha] int identity(1,1));--s Cafe");
    foreach ($Establishment in $Establishments) {
        $MyQuery = "Select LocId,FunctionUsed, [Name] from [dbo].[Establishments] where [Name] = '$Establishment';";
        Write-Verbose $MyQuery;
        Invoke-SQLCmd -ServerInstance $SQLInstance -Database $DemoDatabase -Query $MyQuery;
    }
}
Get-Unsafe;

Invoke-SqlCmd -ServerInstance $SqlInstance -Database $DemoDatabase -Query "select name,create_date from sys.tables" | select-object name, create_date;

<#
$Command = New-Object System.Data.SQLClient.SQLCommand
$Command.Connection = $dbConnection
$Command.CommandText = "INSERT INTO [DataMinutes].dbo.[Establishments] (FunctionUsed,Name) VALUES ('Invoke-SqlCmd',@Establishment)";
$Command.Parameters.Add("@Establishment", $Establishment);
$Command.ExecuteNonQuery();
#>