<#
# Better, Safer SQL Server Queries from PowerShell with `dbatools`
Andy Levy  
Database Administrator, Benefit Resource  
@alevyinroc  
https://flxsql.com/

## The Problem
We need to query SQL Server from PowerShell, either to insert/update data that we're getting from an API, another program, or a user, or to retrive data for the user. But we should never assume that all data provided to us is trustworthy, even data we create ourselves. How can we safely handle this data and not expose our database instances to [SQL injection](https://docs.microsoft.com/en-us/sql/relational-databases/security/sql-injection?view=sql-server-ver15)?
#>

<#
sqlserver module

Invoke-SQLCmd

select * from mytable

Inserting from a file:
Loop!

$MyData = import-csv Path\To\File
foreach ($row in $MyData) {
    $Query = "insert into mytable ('$($row[0])','$($row[1]))"
    invoke-sqlcmd $Query;
}

1) Convenient
2) Potential for poor performance
3) Unsafe!
#>